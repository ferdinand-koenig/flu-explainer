import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import fairness_functions as ff
import dalex as dx 
import plotly
import plotly.express as px
from plotly.subplots import make_subplots
from sklearn.metrics import classification_report, confusion_matrix, roc_curve, auc, ConfusionMatrixDisplay
import warnings
import pickle

plotly.offline.init_notebook_mode()
warnings.filterwarnings("ignore")

with open("models.pkl", "rb") as file:
    # Deserialize and load the object from the file
    models = pickle.load(file)
    
with open("plots.pkl", "rb") as file:
    # Deserialize and load the object from the file
    plots = pickle.load(file)

plotly.offline.init_notebook_mode()
warnings.filterwarnings("ignore")

st.set_page_config(page_title = "Modelling", layout = "wide")

st.title(":brain: Modelling")

h1n1_vaccine_tab, seasonal_vaccine_tab = st.tabs([":microbe: H1N1 Vaccine", ":face_with_thermometer: Seasonal Vaccine"])

# tabs_iter = [(tab36, tab38), (tab36, tab39), (tab36, tab40), 
#              (tab37, tab41), (tab37, tab42), (tab37, tab43)]

# # Model Performance
# for model_tab, sub_tab in zip(tabs, features):
#     with model_tab:
#         with tab:

model = "h1n1_vaccine"

with h1n1_vaccine_tab:
    h1n1_1, h1n1_2, h1n1_3 = st.tabs([":chart_with_upwards_trend: Model Performance", ":bulb: Model Explanations", ":busts_in_silhouette: Model Fairness"])
    with h1n1_1:

        h1h1_p_dist, h1n1_class_report = st.columns([2, 1], vertical_alignment = "center")

        fig = px.histogram(models[model]["predict_proba"][:,1], nbins = 10, title = f"Distribution of Predicted Values for {model}")
        fig.update_traces(marker_line_width = 1, marker_line_color = "black")
        fig.update_layout(xaxis_title = "Probability", yaxis_title = "Count", showlegend = False)
        h1h1_p_dist.plotly_chart(fig)

        with h1n1_class_report:
            st.write("Classification Report:")
            st.dataframe(pd.DataFrame(classification_report(models[model]["y_test"], models[model]["predict"], output_dict = True)).T)

        h1n1_cf, h1n1_roc = st.columns(2)
        with h1n1_cf:
            confusion_matrix_explained = st.expander(":interrobang: Confusion Matrix Explained")
            with confusion_matrix_explained:
                st.markdown('''
                            In the field of machine learning and specifically the problem of statistical classification, a confusion matrix, also known as error matrix, is a specific table layout that allows visualization of the performance of an algorithm, typically a supervised learning one; in unsupervised learning it is usually called a matching matrix.
                            Each row of the matrix represents the instances in an actual class while each column represents the instances in a predicted class, or vice versa – both variants are found in the literature. The name stems from the fact that it makes it easy to see whether the system is confusing two classes (i.e. commonly mislabeling one as another).
                            It is a special kind of contingency table, with two dimensions ("actual" and "predicted"), and identical sets of "classes" in both dimensions (each combination of dimension and class is a variable in the contingency table).
                            
                            [source](https://en.wikipedia.org/wiki/Confusion_matrix)
                            ''')

            fig, ax = plt.subplots()
            ConfusionMatrixDisplay(confusion_matrix = confusion_matrix(models[model]["y_test"], models[model]["predict"])).plot(ax = ax)
            ax.set_title("Confusion Matrix")
            st.pyplot(fig)
            st.expander(":sparkles: Analysis").markdown('''Text''')

        with h1n1_roc:
            roc_curve_explained = st.expander(":interrobang: ROC Curve Explained")
            with roc_curve_explained:
                st.markdown('''
                            A receiver operating characteristic curve, or ROC curve, is a graphical plot that illustrates the performance of a binary classifier model (can be used for multi class classification as well) at varying threshold values.
                            The ROC curve is the plot of the true positive rate (TPR) against the false positive rate (FPR) at each threshold setting.
                            The ROC can also be thought of as a plot of the statistical power as a function of the Type I Error of the decision rule (when the performance is calculated from just a sample of the population, it can be thought of as estimators of these quantities). The ROC curve is thus the sensitivity or recall as a function of false positive rate.
                            Given the probability distributions for both true positive and false positive are known, the ROC curve is obtained as the cumulative distribution function (CDF, area under the probability distribution from 
                            $- \infty$ to the discrimination threshold) of the detection probability in the y-axis versus the CDF of the false positive probability on the x-axis.
                            ROC analysis provides tools to select possibly optimal models and to discard suboptimal ones independently from (and prior to specifying) the cost context or the class distribution. ROC analysis is related in a direct and natural way to the cost/benefit analysis of diagnostic decision making.
                            
                            [source](https://en.wikipedia.org/wiki/Receiver_operating_characteristic)
                            ''')
                
            fig, ax = plt.subplots()
            fpr, tpr, thresholds = roc_curve(models[model]["y_test"], models[model]["predict_proba"][:,1]) 
            roc_auc = auc(fpr, tpr)
            # Plot the ROC curve 
            ax.plot(fpr, tpr, label = f"ROC curve (area = {roc_auc:0.2f})")
            ax.plot([0, 1], [0, 1], 'k--', label='No Skill')
            ax.set_xlim([0.0, 1.0])
            ax.set_ylim([0.0, 1.05])
            ax.set_xlabel('False Positive Rate')
            ax.set_ylabel('True Positive Rate')
            ax.set_title('ROC Curve')
            ax.legend()
            st.pyplot(fig)
            st.expander(":sparkles: Analysis").markdown('''Text''')

    # Model Explanations
    with h1n1_2:
        st.write("#### Variable Importance")
        
        feature_importance_explained = st.expander(":interrobang: Variable Importance Explained")
        with feature_importance_explained:
            st.markdown('''
                        Variable Importance is a step in building a machine learning model that involves calculating the score for all input features in a model to establish the importance of each feature in the decision-making process. 
                        The higher the score for a feature, the larger effect it has on the model to predict a certain variable. 
                        
                        [source](https://builtin.com/data-science/feature-importance#:~:text=Feature%20importance%20is%20a%20step,to%20predict%20a%20certain%20variable.)
                        ''')

        st.plotly_chart(plots[model]["vi"])
        st.markdown('''
                    Here, variable importance is computed by the drop-out loss. 

                    $$\\text{Dropout Loss} = \\text{Performance with all variables} − \\text{Performance with variable dropped}$$

                    A larger dropout loss indicates that the variable is more important because its removal significantly impacts the model's performance.''')

        st.plotly_chart(plots[model]["vi_Protected Characteristics"])
        st.plotly_chart(plots[model]["vi_Opinion Characteristics"])
        st.plotly_chart(plots[model]["vi_Behaviour Characteristics"])
        st.plotly_chart(plots[model]["vi_Health Characteristics"])
        st.plotly_chart(plots[model]["vi_Other Characteristics"])
        st.expander(":sparkles: Analysis").markdown('''Text''')

        st.write("#### Partial Dependence & Accumulated Local Dependence")
        
        partial_dependence_explained = st.expander(":interrobang: Partial Dependence & Accumulated Local Dependence Explained")
        with partial_dependence_explained:
            st.markdown('''
                        The general idea underlying the construction of Partial-dependence (PD) profiles is to show how does the expected value of model prediction behave as a function of a selected explanatory variable. For a single model, one can construct an overall PD profile by using all observations from a dataset, or several profiles for sub-groups of the observations. Comparison of sub-group-specific profiles may provide important insight into, for instance, the stability of the model’s predictions.
                        PD profiles are easy to explain and interpret, especially given their estimation as the mean of ceteris-paribus (CP) profiles. However, the profiles may be misleading if, for instance, explanatory variables are correlated (in ceteris-paribus profiles).
                        Accumulated-local profiles address this issue, and provides a more refined understanding compared to traditional partial dependence plots by focusing on local changes rather than averaging over the entire dataset.

                        [source 1](https://ema.drwhy.ai/partialDependenceProfiles.html)

                        [source 2](https://ema.drwhy.ai/accumulatedLocalProfiles.html)
                        ''')

        st.plotly_chart(plots[model]["pdp_ale_num"])
        st.expander(":sparkles: Analysis").markdown('''Text''')

        st.plotly_chart(plots[model]["pdp_ale_cat"])
        st.expander(":sparkles: Analysis").markdown('''Text''')

        st.write("#### Prediction Breakdown & Shapley Values")

        shapley_values_explained = st.expander(":interrobang: Shapley Values Explained")
        with shapley_values_explained:
            st.markdown('''
                        In explainable machine learning the Shapley value is used to measure the contributions of input features to the output of a machine learning model at the instance level. Given a specific data point, the goal is to decompose the model prediction and assign Shapley values to individual features of the instance.

                        [source](https://www.ijcai.org/proceedings/2022/0778.pdf)
                        ''')

        st.write("#### Most confident model prediction")
        st.write("#### Positive Class (i.e. Vaccinated = 1)")

        st.plotly_chart(plots[model]["bd_1"])
        st.expander(":sparkles: Analysis").markdown('''Text''')

        st.plotly_chart(plots[model]["sh_1"])
        st.expander(":sparkles: Analysis").markdown('''Text''')

        st.write("#### Negative Class (i.e. Not vaccinated = 0)")
        
        st.plotly_chart(plots[model]["bd_0"])
        st.expander(":sparkles: Analysis").markdown('''Text''')

        st.plotly_chart(plots[model]["sh_0"])
        st.expander(":sparkles: Analysis").markdown('''Text''')
        
        st.write("#### Most indecesive model prediction")
        
        st.plotly_chart(plots[model]["bd_05"])
        st.expander(":sparkles: Analysis").markdown('''Text''')

        st.plotly_chart(plots[model]["sh_05"])
        st.expander(":sparkles: Analysis").markdown('''Text''')

        st.write("#### Ceteris Paribus Profiles for Most Confident Predictions")

        ceteris_paribus_explained = st.expander(":interrobang: Ceteris Paribus Profiles Explained")
        with ceteris_paribus_explained:
            st.markdown('''
                        Ceteris-paribus (CP) profiles show how a model’s prediction would change if the value of a single exploratory variable changed. In essence, a CP profile shows the dependence of the conditional expectation of the dependent variable (response) on the values of the particular explanatory variable.

                        [source](https://ema.drwhy.ai/ceterisParibus.html)
                        ''')

        # st.plotly_chart(cp_1.plot(cp_0, show = False))
        st.expander(":sparkles: Analysis").markdown('''Text''')

    # Model Fairness
    with h1n1_3:

        df_preds = pd.concat([
            models[model]["X_test"].reset_index(drop = True),
            models[model]["y_test"].reset_index(drop = True),
            pd.DataFrame(models[model]["predict"], columns = ["predict"]).reset_index(drop = True)],
            axis = 1)
        # fairness_var = st.radio("Select protected characteristic", ["Age", "Sex", "Education", "Income"])
        fairness_sex_0 = ff.group_fairness(df_preds, "chronic_med_condition", 0, "predict", 1)
        fairness_sex_1 = ff.group_fairness(df_preds, "chronic_med_condition", 1, "predict", 1)

        fairness_risk_sex_0 = ff.conditional_statistical_parity(df_preds, "chronic_med_condition", 0, "predict", 1, "opinion_h1n1_risk", 1)
        fairness_risk_sex_1 = ff.conditional_statistical_parity(df_preds, "chronic_med_condition", 1, "predict", 1, "opinion_h1n1_risk", 1)

        parity_sex_0 = ff.predictive_parity(df_preds, "chronic_med_condition", 0, "predict", model)
        parity_sex_1 = ff.predictive_parity(df_preds, "chronic_med_condition", 1, "predict", model)

        er_sex_0 = ff.fp_error_rate_balance(df_preds, "chronic_med_condition", 0, "predict", model)
        er_sex_1 = ff.fp_error_rate_balance(df_preds, "chronic_med_condition", 1, "predict", model)

        st.write("### Fairness Metrics")

        st.markdown(f'''
                    #### Group Fairness
                    
                    :interrobang: Members of each group need to have the same probability of being assigned to the positively predicted class.
                    
                    Chronic Medical Condition class 0 (no):\t{fairness_sex_0}
                    
                    Chronic Medical Condition class 1 (yes):\t{fairness_sex_1}
                    
                    Difference: {np.abs(fairness_sex_0 - fairness_sex_1):.3f}
                    
                    ---
                    ''')

        st.write(f'''
                 #### Conditional Statistical Parity
                    
                 :interrobang: Members of each group need to have the same probability of being assigned to the positive class under the same set of conditions.
                    
                 Opinion Seasonal Risk +Chronic Medical Condition class 0 (no):\t{fairness_risk_sex_0}
                    
                 Opinion Seasonal Risk + Chronic Medical Condition class 1 (yes):\t{fairness_risk_sex_1}
                    
                 Difference: {np.abs(fairness_risk_sex_0 - fairness_risk_sex_1):.3f}
                    
                 ---
                 ''')

        st.write(f'''
                 #### Predictive Parity
                    
                 :interrobang: Members of each group have the same Positive Predictive Value (PPV) — the probability of a subject with Positive Predicted Value to truly belong to the positive class.
                    
                 Chronic Medical Condition class 0 (no):\t{parity_sex_0:.3f}
                    
                 Chronic Medical Condition class 1 (yes):\t{parity_sex_1:.3f}
                    
                 Difference: {np.abs(parity_sex_0 - parity_sex_1):.3f}
                    
                 ---
                 ''')

        st.write(f'''
                 #### False Positive Error Rate Balance
                    
                 :interrobang: Members of each group have the same False Positive Rate (FPR) — the probability of a subject in the negative class to have a positive predicted value.
                    
                 Chronic Medical Condition class 0 (no):\t{er_sex_0:.3f}
                    
                 Chronic Medical Condition class 1 (yes):\t{er_sex_1:.3f}
                    
                 Difference: {np.abs(er_sex_0 - er_sex_1):.3f}
                 ''')
        
model = "seasonal_vaccine"

with seasonal_vaccine_tab:
    seasonal_1, seasonal_2, seasonal_3 = st.tabs([":chart_with_upwards_trend: Model Performance", ":bulb: Model Explanations", ":busts_in_silhouette: Model Fairness"])
    with seasonal_1:

        seasonal_p_dist, seasonal_class_report = st.columns([2, 1], vertical_alignment = "center")

        fig = px.histogram(models[model]["predict_proba"][:,1], nbins = 10, title = f"MLP Classifier: Distribution of Predicted Values for {model}")
        fig.update_traces(marker_line_width = 1, marker_line_color = "black")
        fig.update_layout(xaxis_title = "Probability", yaxis_title = "Count", showlegend = False)
        seasonal_p_dist.plotly_chart(fig)

        with seasonal_class_report:
            st.write("Classification Report:")
            st.dataframe(pd.DataFrame(classification_report(models[model]["y_test"], models[model]["predict"], output_dict = True)).T)

        seasonal_cf, seasonal_roc = st.columns(2)
        with seasonal_cf:
            confusion_matrix_explained = st.expander(":interrobang: Confusion Matrix Explained")
            with confusion_matrix_explained:
                st.markdown('''
                            In the field of machine learning and specifically the problem of statistical classification, a confusion matrix, also known as error matrix, is a specific table layout that allows visualization of the performance of an algorithm, typically a supervised learning one; in unsupervised learning it is usually called a matching matrix.
                            Each row of the matrix represents the instances in an actual class while each column represents the instances in a predicted class, or vice versa – both variants are found in the literature. The name stems from the fact that it makes it easy to see whether the system is confusing two classes (i.e. commonly mislabeling one as another).
                            It is a special kind of contingency table, with two dimensions ("actual" and "predicted"), and identical sets of "classes" in both dimensions (each combination of dimension and class is a variable in the contingency table).
                            
                            [source](https://en.wikipedia.org/wiki/Confusion_matrix)
                            ''')

            fig, ax = plt.subplots()
            ConfusionMatrixDisplay(confusion_matrix = confusion_matrix(models[model]["y_test"], models[model]["predict"])).plot(ax = ax)
            ax.set_title("Confusion Matrix")
            st.pyplot(fig)
            st.expander(":sparkles: Analysis").markdown('''Text''')

        with seasonal_roc:
            roc_curve_explained = st.expander(":interrobang: ROC Curve Explained")
            with roc_curve_explained:
                st.markdown('''
                            A receiver operating characteristic curve, or ROC curve, is a graphical plot that illustrates the performance of a binary classifier model (can be used for multi class classification as well) at varying threshold values.
                            The ROC curve is the plot of the true positive rate (TPR) against the false positive rate (FPR) at each threshold setting.
                            The ROC can also be thought of as a plot of the statistical power as a function of the Type I Error of the decision rule (when the performance is calculated from just a sample of the population, it can be thought of as estimators of these quantities). The ROC curve is thus the sensitivity or recall as a function of false positive rate.
                            Given the probability distributions for both true positive and false positive are known, the ROC curve is obtained as the cumulative distribution function (CDF, area under the probability distribution from 
                            $- \infty$ to the discrimination threshold) of the detection probability in the y-axis versus the CDF of the false positive probability on the x-axis.
                            ROC analysis provides tools to select possibly optimal models and to discard suboptimal ones independently from (and prior to specifying) the cost context or the class distribution. ROC analysis is related in a direct and natural way to the cost/benefit analysis of diagnostic decision making.
                            
                            [source](https://en.wikipedia.org/wiki/Receiver_operating_characteristic)
                            ''')
                
            fig, ax = plt.subplots()
            fpr, tpr, thresholds = roc_curve(models[model]["y_test"], models[model]["predict_proba"][:,1]) 
            roc_auc = auc(fpr, tpr)
            # Plot the ROC curve 
            ax.plot(fpr, tpr, label = f"ROC curve (area = {roc_auc:0.2f})")
            ax.plot([0, 1], [0, 1], 'k--', label='No Skill')
            ax.set_xlim([0.0, 1.0])
            ax.set_ylim([0.0, 1.05])
            ax.set_xlabel('False Positive Rate')
            ax.set_ylabel('True Positive Rate')
            ax.set_title('ROC Curve')
            ax.legend()
            st.pyplot(fig)
            st.expander(":sparkles: Analysis").markdown('''Text''')

    # Model Explanations
    with seasonal_2:
        st.write("#### Variable Importance")
        
        feature_importance_explained = st.expander(":interrobang: Variable Importance Explained")
        with feature_importance_explained:
            st.markdown('''
                        Variable Importance is a step in building a machine learning model that involves calculating the score for all input features in a model to establish the importance of each feature in the decision-making process. 
                        The higher the score for a feature, the larger effect it has on the model to predict a certain variable. 
                        
                        [source](https://builtin.com/data-science/feature-importance#:~:text=Feature%20importance%20is%20a%20step,to%20predict%20a%20certain%20variable.)
                        ''')

        st.plotly_chart(plots[model]["vi"])
        st.markdown('''
                    Here, variable importance is computed by the drop-out loss. 

                    $$\\text{Dropout Loss} = \\text{Performance with all variables} − \\text{Performance with variable dropped}$$

                    A larger dropout loss indicates that the variable is more important because its removal significantly impacts the model's performance.''')
        
        st.plotly_chart(plots[model]["vi_Protected Characteristics"])
        st.plotly_chart(plots[model]["vi_Opinion Characteristics"])
        st.plotly_chart(plots[model]["vi_Behaviour Characteristics"])
        st.plotly_chart(plots[model]["vi_Health Characteristics"])
        st.plotly_chart(plots[model]["vi_Other Characteristics"])
        st.expander(":sparkles: Analysis").markdown('''Text''')

        st.write("#### Partial Dependence & Accumulated Local Dependence")
        
        partial_dependence_explained = st.expander(":interrobang: Partial Dependence & Accumulated Local Dependence Explained")
        with partial_dependence_explained:
            st.markdown('''
                        The general idea underlying the construction of Partial-dependence (PD) profiles is to show how does the expected value of model prediction behave as a function of a selected explanatory variable. For a single model, one can construct an overall PD profile by using all observations from a dataset, or several profiles for sub-groups of the observations. Comparison of sub-group-specific profiles may provide important insight into, for instance, the stability of the model’s predictions.
                        PD profiles are easy to explain and interpret, especially given their estimation as the mean of ceteris-paribus (CP) profiles. However, the profiles may be misleading if, for instance, explanatory variables are correlated (in ceteris-paribus profiles).
                        Accumulated-local profiles address this issue, and provides a more refined understanding compared to traditional partial dependence plots by focusing on local changes rather than averaging over the entire dataset.

                        [source 1](https://ema.drwhy.ai/partialDependenceProfiles.html)

                        [source 2](https://ema.drwhy.ai/accumulatedLocalProfiles.html)
                        ''')

        st.plotly_chart(plots[model]["pdp_ale_num"])
        st.expander(":sparkles: Analysis").markdown('''Text''')

        st.plotly_chart(plots[model]["pdp_ale_cat"])
        st.expander(":sparkles: Analysis").markdown('''Text''')

        st.write("#### Prediction Breakdown & Shapley Values")

        shapley_values_explained = st.expander(":interrobang: Shapley Values Explained")
        with shapley_values_explained:
            st.markdown('''
                        In explainable machine learning the Shapley value is used to measure the contributions of input features to the output of a machine learning model at the instance level. Given a specific data point, the goal is to decompose the model prediction and assign Shapley values to individual features of the instance.

                        [source](https://www.ijcai.org/proceedings/2022/0778.pdf)
                        ''')

        st.write("#### Most confident model prediction")
        st.write("#### Positive Class (i.e. Vaccinated = 1)")

        st.plotly_chart(plots[model]["bd_1"])
        st.expander(":sparkles: Analysis").markdown('''Text''')

        st.plotly_chart(plots[model]["sh_1"])
        st.expander(":sparkles: Analysis").markdown('''Text''')

        st.write("#### Negative Class (i.e. Not vaccinated = 0)")
        
        st.plotly_chart(plots[model]["bd_0"])
        st.expander(":sparkles: Analysis").markdown('''Text''')

        st.plotly_chart(plots[model]["sh_0"])
        st.expander(":sparkles: Analysis").markdown('''Text''')
        
        st.write("#### Most indecesive model prediction")
        
        st.plotly_chart(plots[model]["bd_05"])
        st.expander(":sparkles: Analysis").markdown('''Text''')

        st.plotly_chart(plots[model]["sh_05"])
        st.expander(":sparkles: Analysis").markdown('''Text''')

        st.write("#### Ceteris Paribus Profiles for Most Confident Predictions")

        ceteris_paribus_explained = st.expander(":interrobang: Ceteris Paribus Profiles Explained")
        with ceteris_paribus_explained:
            st.markdown('''
                        Ceteris-paribus (CP) profiles show how a model’s prediction would change if the value of a single exploratory variable changed. In essence, a CP profile shows the dependence of the conditional expectation of the dependent variable (response) on the values of the particular explanatory variable.

                        [source](https://ema.drwhy.ai/ceterisParibus.html)
                        ''')

        # st.plotly_chart(cp_1.plot(cp_0, show = False))
        st.expander(":sparkles: Analysis").markdown('''Text''')

    # Model Fairness
    with seasonal_3:

        df_preds = pd.concat([
            models[model]["X_test"].reset_index(drop = True),
            models[model]["y_test"].reset_index(drop = True),
            pd.DataFrame(models[model]["predict"], columns = ["predict"]).reset_index(drop = True)],
            axis = 1)
        # fairness_var = st.radio("Select protected characteristic", ["Age", "Sex", "Education", "Income"])
        fairness_sex_0 = ff.group_fairness(df_preds, "chronic_med_condition", 0, "predict", 1)
        fairness_sex_1 = ff.group_fairness(df_preds, "chronic_med_condition", 1, "predict", 1)

        fairness_risk_sex_0 = ff.conditional_statistical_parity(df_preds, "chronic_med_condition", 0, "predict", 1, "opinion_seas_risk", 1)
        fairness_risk_sex_1 = ff.conditional_statistical_parity(df_preds, "chronic_med_condition", 1, "predict", 1, "opinion_seas_risk", 1)

        parity_sex_0 = ff.predictive_parity(df_preds, "chronic_med_condition", 0, "predict", model)
        parity_sex_1 = ff.predictive_parity(df_preds, "chronic_med_condition", 1, "predict", model)

        er_sex_0 = ff.fp_error_rate_balance(df_preds, "chronic_med_condition", 0, "predict", model)
        er_sex_1 = ff.fp_error_rate_balance(df_preds, "chronic_med_condition", 1, "predict", model)

        st.write("### Fairness Metrics")

        st.markdown(f'''
                    #### Group Fairness
                    
                    :interrobang: Members of each group need to have the same probability of being assigned to the positively predicted class.
                    
                    Chronic Medical Condition class 0 (no):\t{fairness_sex_0}
                    
                    Chronic Medical Condition class 1 (yes):\t{fairness_sex_1}
                    
                    Difference: {np.abs(fairness_sex_0 - fairness_sex_1):.3f}
                    
                    ---
                    ''')

        st.write(f'''
                 #### Conditional Statistical Parity
                 
                 :interrobang: Members of each group need to have the same probability of being assigned to the positive class under the same set of conditions.
                 
                 Opinion Seasonal Risk +Chronic Medical Condition class 0 (no):\t{fairness_risk_sex_0}
                 
                 Opinion Seasonal Risk + Chronic Medical Condition class 1 (yes):\t{fairness_risk_sex_1}
                 
                 Difference: {np.abs(fairness_risk_sex_0 - fairness_risk_sex_1):.3f}
                 
                 ---
                 ''')
        
        st.write(f'''
                 #### Predictive Parity
                  
                 :interrobang: Members of each group have the same Positive Predictive Value (PPV) — the probability of a subject with Positive Predicted Value to truly belong to the positive class.
                 
                 Chronic Medical Condition class 0 (no):\t{parity_sex_0:.3f}
                 
                 Chronic Medical Condition class 1 (yes):\t{parity_sex_1:.3f}
                 
                 Difference: {np.abs(parity_sex_0 - parity_sex_1):.3f}
                 
                 ---
                 ''')

        st.write(f'''
                 #### False Positive Error Rate Balance
                 
                 :interrobang: Members of each group have the same False Positive Rate (FPR) — the probability of a subject in the negative class to have a positive predicted value.
                 
                 Chronic Medical Condition class 0 (no):\t{er_sex_0:.3f}
                 
                 Chronic Medical Condition class 1 (yes):\t{er_sex_1:.3f}
                 
                 Difference: {np.abs(er_sex_0 - er_sex_1):.3f}
                 ''')