import streamlit as st

st.set_page_config(page_title = "Introduction")

st.title("Explainer Dashboard for Predictions of H1N1 and Seasonal Vaccination Uptake")
st.markdown('''
#### **Proposal**

The data selected for the project is from the [DriveData](https://www.drivendata.org) project: [Flu Shot Learning: Predict H1N1 and Seasonal Flu Vaccines](https://www.drivendata.org/competitions/66/flu-shot-learning/).

From DrivenData's website:

##### **About DrivenData**

DrivenData works on projects at the intersection of data science and social impact, in areas like international development, health, education, research and conservation, and public services. We want to give more organizations access to the capabilities of data science, and engage more data scientists with social challenges where their skills can make a difference.

In pursuit of these goals, DrivenData runs online machine learning competitions with social impact and works directly with mission-driven organizations to drive change through data science and engineering. We also maintain a number of popular open-source projects for the data science community, and have shared the prize-winning solutions from past competitions openly on GitHub for anyone to learn and build from.

##### **Overview**

Predict whether people got H1N1 and seasonal flu vaccines using information shared about backgrounds, opinions, and health behaviors.

In this challenge, we will take a look at vaccination, a key public health measure used to fight infectious diseases. Vaccines provide immunization for individuals, and enough immunization in a community can further reduce the spread of diseases through "herd immunity."

As of the launch of this competition, vaccines for the COVID-19 virus are still under development and not yet available. The competition will instead revisit the public health response to a different recent major respiratory disease pandemic. Beginning in spring 2009, a pandemic caused by the H1N1 influenza virus, colloquially named "swine flu," swept across the world. Researchers estimate that in the first year, it was responsible for between 151,000 to 575,000 deaths globally.

A vaccine for the H1N1 flu virus became publicly available in October 2009. In late 2009 and early 2010, the United States conducted the National 2009 H1N1 Flu Survey. This phone survey asked respondents whether they had received the H1N1 and seasonal flu vaccines, in conjunction with questions about themselves. These additional questions covered their social, economic, and demographic background, opinions on risks of illness and vaccine effectiveness, and behaviors towards mitigating transmission. A better understanding of how these characteristics are associated with personal vaccination patterns can provide guidance for future public health efforts.

##### Initial Questions:

- How accurate can we predict the likelihood of an individuals receiving their H1N1 and seasonal flu vaccines?
    - Specifically using whitebox vs blackbox models
        - Interpretability of AI tools to assist medical decisions needs to be clearly interpretable, understandable, and explainable.
    
- Which features are most important in our predictions?
    - In particular, protected characteristics, and these opinion based features.
        - It will be interesting to compare initial expectations on how influential features will be, vs their _actual_ importance.
    - Can we do some form of feature engineering?

- Is there any bias in our dataset?
    - The topic of vaccines has become very politicised and can be a polarising topic. There are a lot of opinion based features in this dataset. It will be interesting to see if there is any 'baked-in' bias.

- How "fair" are our models, and can this be improved?
    - Excluding certain features (such as protected characteristics, perhaps)
''')